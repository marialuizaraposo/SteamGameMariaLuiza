package ti22.steam.MariaLuiza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MariaLuizaApplicationTests {

	@Test
	void contextLoads() {
	}

}
