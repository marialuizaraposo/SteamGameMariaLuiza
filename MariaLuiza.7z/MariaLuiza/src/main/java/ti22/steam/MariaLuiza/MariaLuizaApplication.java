package ti22.steam.MariaLuiza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MariaLuizaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MariaLuizaApplication.class, args);
	}

}
