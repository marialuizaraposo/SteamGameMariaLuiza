pqackage com.ti22.steam.MariaLuizaago.model;

@Data
@NoArgsConstrutor
@AllArgsConstrutor

public class Usuario {
private int Usuario
}