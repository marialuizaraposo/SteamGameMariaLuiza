package ti22.sinodal.SteamGameMariaLuiza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SteamGameMariaLuizaApplicationTests {

	@Test
	void contextLoads() {
	}

}
