package ti22.sinodal.SteamGameMariaLuiza.model;
import java.util.List;
import java.util.ArrayList;


public abstract class library {
    private int id;
    private List<String> game = new ArrayList<>();
    public abstract void adicionargame();
    public abstract void removergame();



    public library(int id, List<String> game) {
        this.id = id;
        this.game = game;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<String> getGame() {
        return game;
    } 


}