package ti22.sinodal.SteamGameMariaLuiza.model;

public class user{
    private int id;
    private String username;
    private String password;
    private String email;
    private CarteiraVirtual carteiraVirtual;
    
    public user(String nome){
        this.username = nome;
    }
}