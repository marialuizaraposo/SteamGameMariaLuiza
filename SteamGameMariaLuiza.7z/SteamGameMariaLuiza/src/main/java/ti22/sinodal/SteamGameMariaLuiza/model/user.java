package ti22.sinodal.SteamGameMariaLuiza.model;

public class user{
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    private String username;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    private String password;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    private String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    private CarteiraVirtual carteiraVirtual;

    public CarteiraVirtual getCarteiraVirtual() {
        return carteiraVirtual;
    }

    public void setCarteiraVirtual(CarteiraVirtual carteiraVirtual) {
        this.carteiraVirtual = carteiraVirtual;
    }
    
    public user(String nome){
        this.username = nome;
    }
}