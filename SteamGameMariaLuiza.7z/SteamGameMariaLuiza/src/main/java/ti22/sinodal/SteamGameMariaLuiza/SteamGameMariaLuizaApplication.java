package ti22.sinodal.SteamGameMariaLuiza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SteamGameMariaLuizaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SteamGameMariaLuizaApplication.class, args);
	}

}

