package ti22.sinodal.SteamGameMariaLuiza.controller;

public class usercontroller {
   
    
    public void criarUsuario(String username, String password, String email) {
        System.out.println("Usuário criado: " + username);
    }
    
    public void editarUsuario(int id, String novoNome) {
        System.out.println("Usuário editado: " + novoNome);
    }
    
    public void excluirUsuario(int id) {
        System.out.println("Usuário excluído com ID: " + id);
    }
    
}
