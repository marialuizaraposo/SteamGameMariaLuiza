package ti22.sinodal.SteamGameMariaLuiza.model;

import java.util.ArrayList;
import java.util.List;

public class CarteiraVirtual {
    private int id;
    private double saldo;  
    private List<Object> historicoTransacoes; 

    public CarteiraVirtual() {
        this.saldo = 0.0;
        this.historicoTransacoes = new ArrayList<>();
    }
}