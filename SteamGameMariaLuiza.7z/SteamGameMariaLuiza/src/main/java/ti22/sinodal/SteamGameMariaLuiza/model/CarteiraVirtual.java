public class CarteiraVirtual {
    private int id;
    private double saldo;  
    private List String  historicoTransacoes; 

    public CarteiraVirtual() {
        this.saldo = saldo;
        this.historicoTransacoes = historicoTransacoes;
    }
}