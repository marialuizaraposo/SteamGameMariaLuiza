package ti22.sinodal.SteamGameMariaLuiza.model;

import java.util.ArrayList;
import java.util.List;

public class CarteiraVirtual {
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    private double saldo;  

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    private List<Object> historicoTransacoes;

    public List<Object> getHistoricoTransacoes() {
        return historicoTransacoes;
    }

    public void setHistoricoTransacoes(List<Object> historicoTransacoes) {
        this.historicoTransacoes = historicoTransacoes;
    }

    public CarteiraVirtual() {
        this.saldo = 0.0;
        this.historicoTransacoes = new ArrayList<>();
    }
}