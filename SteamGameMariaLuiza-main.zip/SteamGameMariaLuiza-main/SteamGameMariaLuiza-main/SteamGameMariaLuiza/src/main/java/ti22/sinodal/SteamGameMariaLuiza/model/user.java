public class user{
    private Int id;
    private String username;
    private String password;
    private String email;
    private CarteiraVirtual carteiraVirtual;
    
    public user(String nome){
        this.name = nome;
    }
}