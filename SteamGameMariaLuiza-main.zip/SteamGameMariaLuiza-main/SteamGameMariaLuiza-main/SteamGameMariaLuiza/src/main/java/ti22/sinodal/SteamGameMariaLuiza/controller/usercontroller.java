package controller;

import model.User;
import dao.UserDAO;
import exceptions.UserNotFoundException;
import exceptions.DatabaseOperationException;
import exceptions.InvalidUserDataException;

public class UserController {
    private UserDAO userDao;

    public UserController() {
        this.userDao = new UserDAO();
    }

    
      @param user Objeto User 
      @throws InvalidUserDataException
     
    public void addUser(User user) throws InvalidUserDataException {
        try {
            if (user == null || user.getUsername() == null || user.getUsername().trim().isEmpty()) {
                throw new InvalidUserDataException("Dados do usuário inválidos");
            }

            userDao.insert(user);
            
        } catch (DatabaseOperationException e) {
            System.err.println("Erro ao acessar o banco de dados: " + e.getMessage());
            throw e;
        } finally {

        }
    }

    
     @param 
     @return
     @throws UserNotFoundException Se 
     
    public User getUserById(int userId) throws UserNotFoundException {
        try {
            User user = userDao.getById(userId);
            
            if (user == null) {
                throw new UserNotFoundException("Usuário com ID " + userId + " não encontrado");
            }
            
            return user;
            
        } catch (DatabaseOperationException e) {
            System.err.println("Erro ao acessar o banco de dados: " + e.getMessage());
            throw new UserNotFoundException("Erro ao buscar usuário", e);
        }
    }


      @param user 
      @throws UserNotFoundException 
      @throws InvalidUserDataException 
     
    public void updateUser(User user) throws UserNotFoundException, InvalidUserDataException {
        try {

            if (user == null || user.getUsername() == null || user.getUsername().trim().isEmpty()) {
                throw new InvalidUserDataException("Dados do usuário inválidos");
            }
            if (!userDao.exists(user.getId())) {
                throw new UserNotFoundException("Usuário não encontrado para atualização");
            }

            userDao.update(user);
            
        } catch (DatabaseOperationException e) {
            System.err.println("Erro ao acessar o banco de dados: " + e.getMessage());
            throw new DatabaseOperationException("Erro ao atualizar usuário", e);
        }
    }

     
      @param userId 
      @throws UserNotFoundException 
     
    public void deleteUser(int userId) throws UserNotFoundException {
        try {

            if (!userDao.exists(userId)) {
                throw new UserNotFoundException("Usuário não encontrado para exclusão");
            }

            userDao.delete(userId);
            
        } catch (DatabaseOperationException e) {
            System.err.println("Erro ao acessar o banco de dados: " + e.getMessage());
            throw new DatabaseOperationException("Erro ao deletar usuário", e);
        } finally {

        }
    }

  
     * Método para autenticar um usuário
     * @param username 
     * @param password S
     * @return 
     * @throws UserNotFoundException 
     * 
    public User authenticate(String username, String password) throws UserNotFoundException {
        try {
            User user = userDao.getByUsername(username);
            
            if (user == null || !user.getPassword().equals(password)) {
                throw new UserNotFoundException("Credenciais inválidas");
            }
            
            return user;
            
        } catch (DatabaseOperationException e) {
            System.err.println("Erro ao acessar o banco de dados: " + e.getMessage());
            throw new UserNotFoundException("Erro durante autenticação", e);
        }
    }
}